import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
from diffusers import Cosmos3OmniPipeline

pipe = Cosmos3OmniPipeline.from_pretrained("nvidia/Cosmos3-Nano", torch_dtype=torch.bfloat16, enable_safety_checker=False)
pipe.enable_sequential_cpu_offload()

prompt = (
    "Direct top-down bird's-eye view of a single industrial conveyor belt running vertically "
    "from the top to the bottom of the frame. The conveyor has a black rubber belt and metal "
    "side rails. Static camera, entire conveyor fully visible in frame, no motion blur. "
    "At the very top of the belt, a green cube and a red cube sit centered on the conveyor, "
    "aligned along the belt direction. The green cube is positioned one foot upstream of the "
    "red cube (green at the top of the frame, red one foot below it moving toward the bottom). "
    "Both cubes are identical in size, square, and solid-colored. "
    "A small black rectangular opaque proximity sensor is mounted on the left side rail near the "
    "bottom of the frame, oriented to face upward along the belt toward approaching cubes. The sensor "
    "has a tiny red indicator LED in its top-left corner, currently unlit. "
    "Clean gray factory floor visible around the conveyor. Even overhead LED lighting, "
    "soft shadows, sharp focus. Photorealistic industrial photograph, high detail, not CGI."
)


result = pipe(prompt, num_frames=1, height=480, width=848, num_inference_steps=40)
image = result.video[0]
os.makedirs("output", exist_ok=True)
image.save("output/1.jpg", format="JPEG", quality=85)
print("Saved output/1.jpg")
