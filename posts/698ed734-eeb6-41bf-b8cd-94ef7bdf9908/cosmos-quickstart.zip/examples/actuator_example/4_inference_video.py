import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
from transformers import AutoProcessor, Cosmos3OmniForConditionalGeneration

video_path = "output/3.mp4"

model = Cosmos3OmniForConditionalGeneration.from_pretrained(
    "nvidia/Cosmos3-Nano", torch_dtype=torch.bfloat16, device_map="auto"
)
processor = AutoProcessor.from_pretrained("nvidia/Cosmos3-Nano")

messages = [
    {
        "role": "user",
        "content": [
            {"type": "video", "video": video_path},
            {
                "type": "text",
                "text": (
                    "Describe in detail what is happening in this video. "
                    "Identify the objects, their movements, and any interactions between them."
                ),
            },
        ],
    }
]

inputs = processor.apply_chat_template(
    messages,
    tokenize=True,
    add_generation_prompt=True,
    return_dict=True,
    return_tensors="pt",
).to(model.device)

output_ids = model.generate(**inputs, max_new_tokens=512)
generated = [out[len(inp):] for inp, out in zip(inputs.input_ids, output_ids)]
response = processor.batch_decode(generated, skip_special_tokens=True)[0]

print("\n=== Video Analysis ===")
print(f"Video: {video_path}")
print(f"\n{response}")

os.makedirs("output", exist_ok=True)
with open("output/4_analysis.txt", "w") as f:
    f.write(response)
print("\nSaved output/4_analysis.txt")
