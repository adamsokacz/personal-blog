import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
from diffusers import Cosmos3OmniPipeline
from diffusers.utils import export_to_video, load_image

image_path = "output/1.jpg"

pipe = Cosmos3OmniPipeline.from_pretrained(
    "nvidia/Cosmos3-Nano", torch_dtype=torch.bfloat16, enable_safety_checker=False
)
pipe.enable_sequential_cpu_offload()

prompt = (
    "Static top-down bird's-eye camera, entire conveyor fully visible in frame, no camera movement. "
    "A single vertical conveyor belt with a black rubber surface and metal side rails runs from the "
    "top to the bottom of the frame, moving downward. A green cube and a red cube, identical in size, "
    "start at the very top of the belt centered on the conveyor. The green cube leads at the top and "
    "the red cube follows one foot below it, maintaining that fixed one-foot separation throughout. "
    "Both cubes always move at the same rate, locked together on the belt with no relative motion "
    "between them. They travel down at a constant shared speed from the top toward the bottom of the frame. "
    "A small black rectangular proximity sensor is mounted on the left side rail near the bottom of "
    "the frame, facing the belt. Its indicator LED in the top-left corner glows green while the cubes "
    "approach from above. When the red cube moves directly in front of the sensor near the bottom, "
    "the sensor responds: the LED changes from green to red. At the exact moment the light turns red, "
    "both cubes stop moving immediately and remain frozen in place on the belt. "
    "No new objects enter the scene. Only one green cube and one red cube exist. "
    "Even overhead factory lighting, photorealistic industrial video, smooth motion, no motion blur."
)
image = load_image(image_path)

result = pipe(prompt, image=image, num_frames=80, height=480, width=848, fps=24.0, num_inference_steps=40)
os.makedirs("output", exist_ok=True)
export_to_video(result.video, "output/3.mp4", fps=24, macro_block_size=1)
print("Saved output/3.mp4")
