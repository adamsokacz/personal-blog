import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import torch
import imageio.v3 as iio
from PIL import Image
from diffusers import Cosmos3OmniPipeline
from diffusers.utils import export_to_video

video_path = "output/5.mp4"

frames = iio.imread(video_path, plugin="pyav")
image = Image.fromarray(frames[-1])

pipe = Cosmos3OmniPipeline.from_pretrained(
    "nvidia/Cosmos3-Nano", torch_dtype=torch.bfloat16, enable_safety_checker=False
)
pipe.enable_sequential_cpu_offload()

prompt = (
    "Static top-down bird's-eye camera, entire conveyor fully visible in frame, no camera movement. "
    "Continuation from the previous moment: a green cube and a red cube, identical in size, continue "
    "moving down a vertical conveyor belt with a black rubber surface and metal side rails that runs "
    "from the top to the bottom of the frame. The green cube leads and the red cube follows one foot "
    "below it, maintaining that fixed separation. Both cubes always move at the same rate, locked "
    "together on the belt with no relative motion between them. They keep moving down at the same "
    "constant shared speed as before, never slowing, never stopping, and never reversing. They travel "
    "downward toward the bottom of the frame until the red cube exits completely below the bottom "
    "edge, followed by the green cube, until both cubes are fully out of frame and only the empty "
    "conveyor belt remains visible. "
    "A small black rectangular proximity sensor mounted on the left side rail near the bottom of the "
    "frame has already been passed. Its indicator LED in the top-left corner remains green throughout. "
    "No new objects enter the scene. Only one green cube and one red cube exist. "
    "Even overhead factory lighting, photorealistic industrial video, smooth continuous motion, "
    "no motion blur."
)

result = pipe(prompt, image=image, num_frames=49, height=480, width=848, fps=24.0, num_inference_steps=40)
os.makedirs("output", exist_ok=True)
export_to_video(result.video, "output/6.mp4", fps=24, macro_block_size=1)
print("Saved output/6.mp4")
