import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import json
import re

import torch
from PIL import Image, ImageDraw, ImageFont
from transformers import AutoProcessor, Cosmos3OmniForConditionalGeneration

image_path = "output/1.jpg"

model = Cosmos3OmniForConditionalGeneration.from_pretrained(
    "nvidia/Cosmos3-Nano", torch_dtype=torch.bfloat16, device_map="auto"
)
processor = AutoProcessor.from_pretrained("nvidia/Cosmos3-Nano")

messages = [
    {
        "role": "user",
        "content": [
            {"type": "image", "image": image_path},
            {
                "type": "text",
                "text": (
                    "Locate every distinct object in this image. "
                    "For each object, output a JSON object with keys "
                    '"label" (short name) and "bbox_2d" [x_min, y_min, x_max, y_max] '
                    "where coordinates are relative values from 0 to 1000. "
                    "Return a JSON array of these objects, nothing else."
                ),
            },
        ],
    }
]

inputs = processor.apply_chat_template(
    messages,
    tokenize=True,
    add_generation_prompt=True,
    return_dict=True,
    return_tensors="pt",
).to(model.device)

output_ids = model.generate(**inputs, max_new_tokens=2048)
generated = [out[len(inp):] for inp, out in zip(inputs.input_ids, output_ids)]
response = processor.batch_decode(generated, skip_special_tokens=True)[0]

print("\n=== Raw Reasoning Output ===")
print(response)

os.makedirs("output", exist_ok=True)
with open("output/2_analysis.txt", "w") as f:
    f.write(response)
print("\nSaved output/2_analysis.txt")

# --- Parse bounding boxes from the response ---

def extract_boxes(text):
    """Try to parse a JSON array of {label, bbox_2d} objects from model output."""
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    objects = []
    for m in re.finditer(
        r'"label"\s*:\s*"([^"]+)"[^}]*"bbox_2d"\s*:\s*\[([^\]]+)\]', text
    ):
        label = m.group(1)
        coords = [float(c.strip()) for c in m.group(2).split(",")]
        if len(coords) == 4:
            objects.append({"label": label, "bbox_2d": coords})
    return objects

objects = extract_boxes(response)

if not objects:
    print("\nNo bounding boxes parsed — saving raw analysis only.")
    raise SystemExit(0)

# --- Draw boxes onto the image ---

COLORS = [
    "#FF3B30", "#34C759", "#007AFF", "#FF9500", "#AF52DE",
    "#FFD60A", "#30D5C8", "#FF2D55", "#5AC8FA", "#FFCC00",
]

img = Image.open(image_path).convert("RGB")
w, h = img.size
draw = ImageDraw.Draw(img)

try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
except OSError:
    font = ImageFont.load_default()

for i, obj in enumerate(objects):
    label = obj.get("label", f"object_{i}")
    bbox = obj.get("bbox_2d", [])
    if len(bbox) != 4:
        continue

    x_min = bbox[0] / 1000 * w
    y_min = bbox[1] / 1000 * h
    x_max = bbox[2] / 1000 * w
    y_max = bbox[3] / 1000 * h

    color = COLORS[i % len(COLORS)]
    draw.rectangle([x_min, y_min, x_max, y_max], outline=color, width=3)

    text_bbox = font.getbbox(label)
    tw, th = text_bbox[2] - text_bbox[0], text_bbox[3] - text_bbox[1]
    label_y = max(y_min - th - 6, 0)
    draw.rectangle([x_min, label_y, x_min + tw + 8, label_y + th + 6], fill=color)
    draw.text((x_min + 4, label_y + 2), label, fill="white", font=font)

img.save("output/2.jpg", format="JPEG", quality=90)
print(f"\nDrew {len(objects)} bounding boxes → output/2.jpg")
